/**
 * ============================================================
 * SWEET MUSIC OS — PATCH SCRIPT
 * Apply in github.dev terminal or copy-paste into browser console
 * Target repo: Torreyw94/tsm-shell
 * ============================================================
 *
 * This file documents all FIND → REPLACE operations needed
 * to upgrade the existing music-command files to Sweet Music OS.
 * 
 * HOW TO USE IN GITHUB.DEV:
 * 1. Open each file listed below
 * 2. Use Ctrl+H (Find & Replace) in the editor
 * 3. Apply the patches in order
 * ============================================================
 */

// ============================================================
// FILE: html/music-command/index.html
// ACTION: Replace the entire file with the new index.html
// (Upload sweet-music-os/index.html directly)
// ============================================================

// ============================================================
// FILE: html/music-command/app.html
// PATCHES (apply in order via Ctrl+H):
// ============================================================

const APP_HTML_PATCHES = [

  // 1. Update page title
  {
    find: `<title>Music Command Center</title>`,
    replace: `<title>Sweet Music™ OS · TSM Music Command</title>`
  },

  // 2. Update main heading (find in the HTML body)
  {
    find: `Music Command Center`,
    replace: `Sweet Music™ OS`
  },

  // 3. Wire nav tabs to new module pages
  // In the nav/sidebar section, replace any static tab that links to beat-suno-cadence-panels.html
  {
    find: `beat-suno-cadence-panels.html`,
    replace: `creation/beat-workbench.html`
  },

  // 4. Replace how-to-guide link
  {
    find: `how-to-guide.html`,
    replace: `academy/daw-academy.html`
  },

  // 5. Replace marketing link
  {
    find: `marketing.html`,
    replace: `release/marketing.html`
  },

  // 6. Replace producer intel panel link
  {
    find: `producer-intel-panel.html`,
    replace: `producer/producer-ai.html`
  },

  // 7. Replace demo conductor link
  {
    find: `demo-conductor.html`,
    replace: `academy/daw-academy.html`
  },

  // 8. Replace playback-banger link
  {
    find: `playback-banger.html`,
    replace: `creation/cadence-builder.html`
  },

  // 9. Update any "Music Command" brand references in body copy
  {
    find: `Music Command`,
    replace: `Sweet Music™ OS`
  },

  // 10. Update subtitle/tagline if present
  {
    find: `AI Music Production`,
    replace: `AI Music Production Operating System`
  },

  // 11. Wire the existing Groq calls to use the correct TSM Neural Core label
  // (app.html may call groq directly with old key references)
  {
    find: `GROQ_KEY()`,
    replace: `localStorage.getItem('GROQ_API_KEY')`
  },

  // 12. If app.html has a hardcoded nav that renders module cards, add Sweet Music OS branding
  {
    find: `class="main-title"`,
    replace: `class="main-title smos-branded"`
  }

];

// ============================================================
// FILE: html/music-command/beat-suno-cadence-panels.html
// PATCHES:
// ============================================================

const BEAT_PANELS_PATCHES = [

  // 1. Update title
  {
    find: `<title>`,
    replace: `<!-- OLD FILE — see creation/beat-workbench.html for replacement -->\n  <title>`
  },

  // 2. The "Generate Prompt" button CTA
  {
    find: `Generate Prompt`,
    replace: `Generate Beat Intelligence`
  },

  // 3. Simple URL input label if present
  {
    find: `Enter beat URL`,
    replace: `Paste BeatStars / SoundCloud / YouTube link`
  },

  // 4. Any old Groq endpoint references
  {
    find: `/api/groq`,
    replace: `/api/neural-core`
  }

];

// ============================================================
// FILE: html/music-command/producer-intel-panel.html
// PATCHES:
// ============================================================

const PRODUCER_INTEL_PATCHES = [

  {
    find: `Producer Intel`,
    replace: `Producer AI · Sweet Music™ OS`
  },

  {
    find: `<title>Producer Intel Panel</title>`,
    replace: `<title>Producer AI · Sweet Music™ OS</title>`
  },

  // Wire any "back" link
  {
    find: `href="../app.html"`,
    replace: `href="../index.html"`
  },

  {
    find: `href="app.html"`,
    replace: `href="index.html"`
  }

];

// ============================================================
// FILE: html/music-command/marketing.html
// PATCHES:
// ============================================================

const MARKETING_PATCHES = [

  {
    find: `<title>Marketing</title>`,
    replace: `<title>Artist Growth · Sweet Music™ OS</title>`
  },

  {
    find: `Marketing`,
    replace: `Artist Growth`
  }

];

// ============================================================
// NEW FILES TO CREATE IN github.dev
// Upload each from sweet-music-os/ package:
// ============================================================

const NEW_FILES = [
  {
    path: `html/music-command/index.html`,
    source: `sweet-music-os/index.html`,
    note: `New dashboard — replaces current index.html`
  },
  {
    path: `html/music-command/creation/song-builder.html`,
    source: `sweet-music-os/creation/song-builder.html`,
    note: `8-step guided song writing wizard with AI`
  },
  {
    path: `html/music-command/creation/beat-workbench.html`,
    source: `sweet-music-os/creation/beat-workbench.html`,
    note: `Beat intelligence engine — upload or link`
  },
  {
    path: `html/music-command/creation/cadence-builder.html`,
    source: `sweet-music-os/creation/cadence-builder.html`,
    note: `Interactive cadence/syllable studio`
  },
  {
    path: `html/music-command/producer/producer-ai.html`,
    source: `sweet-music-os/producer/producer-ai.html`,
    note: `Producer AI collaborator with song scoring`
  },
  {
    path: `html/music-command/producer/recording-coach.html`,
    source: `sweet-music-os/producer/recording-coach.html`,
    note: `Pre-session checklist + vocal guidance`
  },
  {
    path: `html/music-command/producer/mixing-coach.html`,
    source: `sweet-music-os/producer/mixing-coach.html`,
    note: `EQ, compression, reverb, width coaching`
  },
  {
    path: `html/music-command/producer/mastering-coach.html`,
    source: `sweet-music-os/producer/mastering-coach.html`,
    note: `LUFS, limiting, streaming readiness`
  },
  {
    path: `html/music-command/academy/daw-academy.html`,
    source: `sweet-music-os/academy/daw-academy.html`,
    note: `DAW comparison + AI coach (replaces how-to-guide.html)`
  },
  {
    path: `html/music-command/academy/music-theory.html`,
    source: `sweet-music-os/academy/music-theory.html`,
    note: `Keys, scales, chords for your genre`
  },
  {
    path: `html/music-command/academy/music-business.html`,
    source: `sweet-music-os/academy/music-business.html`,
    note: `Publishing, PRO, royalties, splits`
  },
  {
    path: `html/music-command/release/release-center.html`,
    source: `sweet-music-os/release/release-center.html`,
    note: `Full distribution checklist + AI press bio generator`
  },
  {
    path: `html/music-command/release/marketing.html`,
    source: `sweet-music-os/release/marketing.html`,
    note: `Artist growth — Spotify, TikTok, YouTube rollout`
  },
  {
    path: `html/music-command/js/sweet-music-engine.js`,
    source: `sweet-music-os/js/sweet-music-engine.js`,
    note: `Core engine — localStorage bus between all modules`
  }
];

/**
 * ============================================================
 * SUITE BUILDER REGISTRATION
 * Add these entries to your suite-builder.html catalog
 * ============================================================
 */
const SUITE_BUILDER_ENTRIES = [
  { id: 'smos-index',        label: 'Sweet Music™ OS Dashboard',      path: 'music-command/index.html',                    category: 'Music Command' },
  { id: 'smos-song-builder', label: 'Song Builder Wizard',             path: 'music-command/creation/song-builder.html',    category: 'Music Command' },
  { id: 'smos-beat-wb',      label: 'Beat Workbench',                  path: 'music-command/creation/beat-workbench.html',  category: 'Music Command' },
  { id: 'smos-cadence',      label: 'Cadence Studio',                  path: 'music-command/creation/cadence-builder.html', category: 'Music Command' },
  { id: 'smos-producer',     label: 'Producer AI',                     path: 'music-command/producer/producer-ai.html',     category: 'Music Command' },
  { id: 'smos-rec',          label: 'Recording Coach',                 path: 'music-command/producer/recording-coach.html', category: 'Music Command' },
  { id: 'smos-mix',          label: 'Mix Coach',                       path: 'music-command/producer/mixing-coach.html',    category: 'Music Command' },
  { id: 'smos-master',       label: 'Master Coach',                    path: 'music-command/producer/mastering-coach.html', category: 'Music Command' },
  { id: 'smos-daw',          label: 'DAW Academy',                     path: 'music-command/academy/daw-academy.html',      category: 'Music Command' },
  { id: 'smos-theory',       label: 'Music Theory',                    path: 'music-command/academy/music-theory.html',     category: 'Music Command' },
  { id: 'smos-biz',          label: 'Music Business AI',               path: 'music-command/academy/music-business.html',   category: 'Music Command' },
  { id: 'smos-release',      label: 'Release Center',                  path: 'music-command/release/release-center.html',   category: 'Music Command' },
  { id: 'smos-growth',       label: 'Artist Growth / Marketing',       path: 'music-command/release/marketing.html',        category: 'Music Command' },
];

module.exports = { APP_HTML_PATCHES, BEAT_PANELS_PATCHES, PRODUCER_INTEL_PATCHES, MARKETING_PATCHES, NEW_FILES, SUITE_BUILDER_ENTRIES };

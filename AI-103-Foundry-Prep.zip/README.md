# AI-103 Foundry Prep System

Full AI-103 certification training system:
- Study Guide (Markdown)
- Flashcards (JSON)
- Exam Engine (HTML)
- AI Tutor Mode (Node.js)
- Cheat Sheet (1-page)

## Run Exam Engine
Open:
exams/timed-engine.html

## Flashcards
flashcards/*.json

## Tutor CLI
node tools/tutor.js

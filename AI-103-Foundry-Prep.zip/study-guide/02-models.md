# Models & Deployment
- Chat / Reasoning / Vision / Speech models
- Global Standard / Data Zone / Batch deployments

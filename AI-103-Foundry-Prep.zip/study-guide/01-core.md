# Foundry Core
- Projects
- Foundry IQ (RAG)
- Tools ecosystem

# Agents
- Agent Service
- MCP tool calling
- Stateful conversations

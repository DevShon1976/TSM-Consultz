# AI-103 Cheat Sheet

- Foundry = AI platform
- RAG = external knowledge grounding
- Agents = tool-using AI systems
- SDKs = Foundry SDK + OpenAI SDK

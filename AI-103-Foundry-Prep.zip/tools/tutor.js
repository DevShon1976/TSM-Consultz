const readline = require('readline');

const qa = [
 {q:"What is RAG?", a:"Retrieval Augmented Generation"},
 {q:"What is Foundry?", a:"Azure AI platform"}
];

let i=0;

const rl = readline.createInterface({
 input: process.stdin,
 output: process.stdout
});

function ask(){
 if(i>=qa.length){
   console.log("Done");
   process.exit();
 }
 rl.question(qa[i].q+" ", (answer)=>{
   console.log("Expected:", qa[i].a);
   i++;
   ask();
 });
}

ask();

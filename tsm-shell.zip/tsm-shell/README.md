# TSM Shell

AI-powered backend with persistent prompt logic via Groq.

## Structure

```
tsm-shell/
├── .devcontainer/devcontainer.json   ← Codespaces config (autosave, autosetup)
├── ai/
│   ├── prompts/                      ← Edit these to change AI behavior
│   │   ├── wip.md
│   │   ├── billing.md
│   │   ├── insurance.md
│   │   ├── healthcare.md
│   │   └── finops.md
│   └── workflows/                    ← Metadata for each workflow
├── services/aiExecutor.js            ← Groq call logic
├── utils/loadPrompt.js               ← Reads prompts from files
├── routes/ai.js                      ← HTTP endpoints
├── server.js                         ← Entry point
├── Dockerfile                        ← For Fly.io
└── fly.toml                          ← Fly.io config
```

## Setup

### 1. Set your Groq API key in Fly
```bash
flyctl secrets set GROQ_API_KEY=your_key_here
```

### 2. Deploy
```bash
flyctl deploy
```

### 3. Test an endpoint
```bash
curl -X POST https://your-app.fly.dev/ai/wip \
  -H "Content-Type: application/json" \
  -d '{"message": "What should I work on today?"}'
```

## Adding a new AI workflow

1. Create `ai/prompts/myworkflow.md` with the system prompt
2. Create `ai/workflows/myworkflow.json` with metadata
3. Call `POST /ai/myworkflow` — no code changes needed

## End-of-session habit
```bash
git add .
git commit -m "session: what I changed"
git push
```

import Groq from "groq-sdk";
import { loadPrompt } from "../utils/loadPrompt.js";

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });

/**
 * Run an AI call using a named prompt file + user message.
 * @param {string} promptName - filename in ai/prompts/ (without .md)
 * @param {string} userMessage - the user's input
 * @param {string} model - groq model to use
 */
export async function runAI(promptName, userMessage, model = "llama3-70b-8192") {
  const systemPrompt = loadPrompt(promptName);

  const response = await groq.chat.completions.create({
    model,
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userMessage }
    ]
  });

  return response.choices[0].message.content;
}

import { Router } from "express";
import { runAI } from "../services/aiExecutor.js";

const router = Router();

// POST /ai/:prompt  — e.g. POST /ai/wip, /ai/billing, /ai/insurance
router.post("/:prompt", async (req, res) => {
  const { prompt } = req.params;
  const { message } = req.body;

  if (!message) {
    return res.status(400).json({ error: "message is required" });
  }

  try {
    const result = await runAI(prompt, message);
    res.json({ result });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;

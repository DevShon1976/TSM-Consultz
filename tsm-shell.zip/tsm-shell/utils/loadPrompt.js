import { readFileSync } from "fs";
import { fileURLToPath } from "url";
import { dirname, join } from "path";

const __dirname = dirname(fileURLToPath(import.meta.url));

/**
 * Load a prompt from ai/prompts/<name>.md
 * @param {string} name - prompt filename without extension
 * @returns {string} prompt text
 */
export function loadPrompt(name) {
  const promptPath = join(__dirname, "../ai/prompts", `${name}.md`);
  try {
    return readFileSync(promptPath, "utf-8");
  } catch {
    throw new Error(`Prompt not found: ${name}.md — add it to ai/prompts/`);
  }
}
